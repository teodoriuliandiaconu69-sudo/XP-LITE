Windows XP Lite Build Wizard v1.0

Instructions:

1. Place this folder anywhere on your computer.
2. Run nLite_LiteWizard.bat as Administrator.
3. Enter the path to your Windows XP source files (CD or extracted ISO).
4. Select a Lite profile: Basic, Extreme, Barebones, or Custom.
5. The script will generate Last_Session.ini in XP_LITE_BUILD folder.
6. nLite will automatically launch with the working directory loaded.
7. Follow nLite's wizard to create your custom Lite ISO.
